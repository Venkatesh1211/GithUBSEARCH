package api

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query
import model.Contributor
import model.RepositoryResponse

interface GitHubApiService {
    // Search repositories based on the query
    @GET("search/repositories")
    suspend fun searchRepositories(
        @Query("q") query: String,
        @Query("page") page: Int,
        @Query("per_page") perPage: Int = 10 // Limit to 10 results per page
    ): Response<RepositoryResponse>

    // Get contributors of a repository
    @GET
    suspend fun getContributors(
        @Query("contributors_url") url: String
    ): Response<List<Contributor>>
}
