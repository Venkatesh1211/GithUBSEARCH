package com.example.githubreposearchapp

import android.app.Application
import com.example.githubreposearchapp.database.AppDatabase

class GitHubRepoSearchApp : Application() {
    lateinit var database: AppDatabase

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getDatabase(this)
    }
}
