package com.example.githubreposearchapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.githubreposearchapp.database.AppDatabase
import com.example.githubreposearchapp.repository.RepositoryRepository
import kotlinx.coroutines.launch
import model.Repository

class RepositoryViewModel(database: AppDatabase) : ViewModel() {
    private val repository = RepositoryRepository(database)

    // Function to insert repositories
    fun insertRepositories(repositories: List<Repository>) {
        viewModelScope.launch {
            repository.insertRepositories(repositories)
        }
    }

    // Function to get all repositories
    suspend fun getAllRepositories(): List<Repository> {
        return repository.getAllRepositories()
    }
}
