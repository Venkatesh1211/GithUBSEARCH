package com.example.githubreposearchapp.repository

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.githubreposearchapp.database.AppDatabase
import com.example.githubreposearchapp.viewmodel.RepositoryViewModel

class RepositoryViewModelFactory(private val database: AppDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RepositoryViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return RepositoryViewModel(database) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
