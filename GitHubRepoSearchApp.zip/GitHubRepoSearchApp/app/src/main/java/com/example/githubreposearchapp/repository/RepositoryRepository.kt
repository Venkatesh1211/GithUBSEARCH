package com.example.githubreposearchapp.repository

import androidx.lifecycle.LiveData
import com.example.githubreposearchapp.database.AppDatabase
import model.Repository

class RepositoryRepository(private val database: AppDatabase) {

    // Insert repositories into the database
    suspend fun insertRepositories(repositories: List<Repository>) {
        database.repositoryDao().insertRepositories(repositories)
    }

    // Fetch all repositories from the database
    suspend fun getAllRepositories(): List<Repository> {
        return database.repositoryDao().getAllRepositories() // Ensure this returns LiveData
    }
}
