package com.example.githubreposearchapp

import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer // Ensure this is imported
import android.os.Bundle
import com.example.githubreposearchapp.database.AppDatabase
import com.example.githubreposearchapp.repository.RepositoryViewModelFactory
import com.example.githubreposearchapp.viewmodel.RepositoryViewModel
import model.Repository


class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: RepositoryViewModel

    override suspend fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the database and ViewModel
        val database = AppDatabase.getDatabase(applicationContext)
        val viewModelFactory = RepositoryViewModelFactory(database)
        viewModel = viewModels<RepositoryViewModel> { viewModelFactory }.value

        // Example data to insert
        val repositories = listOf(
            Repository(1, "Repo1", "owner1", "http://example.com", "Description 1", "http://example.com/contributors"),
            Repository(2, "Repo2", "owner2", "http://example.com", "Description 2", "http://example.com/contributors")
        )

        // Call insertRepositories
        viewModel.insertRepositories(repositories)

        // Observe the LiveData
        viewModel.getAllRepositories().observe(this, Observer { repos ->
            // Update UI with the list of repositories
            // Example: Update RecyclerView Adapter here
        })
    }
}
