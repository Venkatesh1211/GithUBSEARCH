package model

data class Contributor(
    val login: String,
    val contributions: Int
)
