package model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "repositories")
class Repository // Constructor, getters, and setters
    (
    @field:PrimaryKey var id: Int,
    var name: String,
    var owner: String,
    var html_url: String,
    var description: String,
    var contributors_url: String
) :
    Serializable