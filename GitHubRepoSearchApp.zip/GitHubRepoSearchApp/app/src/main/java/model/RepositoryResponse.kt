package model

import com.example.githubreposearchapp.database.AppDatabase

data class RepositoryResponse(
    val items: AppDatabase
)


